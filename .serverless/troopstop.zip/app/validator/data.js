function dataValidator(req, res, next) {
    next();
}

module.exports = dataValidator;