### Troop Stop

Live URL: https://eamvi25p1a.execute-api.ap-south-1.amazonaws.com/production/